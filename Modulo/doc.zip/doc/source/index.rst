.. Juanchin documentation master file, created by
   sphinx-quickstart on Wed Jul 17 21:30:04 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Juanchin's documentation!
====================================

Esto es un texto cualquiera.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: app
     :members:
     :special-members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
